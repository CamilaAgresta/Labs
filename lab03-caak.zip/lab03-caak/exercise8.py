"""
Bachelor in Data Science and Engineering 
Subject: Programming
Created by Camila Alba Agresta Kohen  
Created on 28/9/25 at 22:06
Universidad Carlos III de Madrid
Student

-------
Lab 3
Exercise: 8 - Multiple declarations (II)
Type the following program:
var1, var2 = 4, 6
var1, var2 = 8, var1
Which is the final value of each variable? Why?
"""

var1, var2 = 4, 6
var1, var2 = 8, var1

print("var1:", var1)
print("var2:", var2)

