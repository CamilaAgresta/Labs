"""
Bachelor in Data Science and Engineering 
Subject: Programming
Created by Camila Alba Agresta Kohen  
Created on 28/9/25 at 21:07
Universidad Carlos III de Madrid
Student

-------
Lab 3
Exercise: 4 - Changing the type of a variable
Declare and initialize an integer variable. On the next line, change its content to store 'hello'. Is this possible?
What is the name of the Python feature that allows this?
"""

var = 8
print(var)

var = "hello"
print(var)

# It is possible
# This is called dynamic types
