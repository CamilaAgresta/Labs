"""
Bachelor in Data Science and Engineering 
Subject: Programming
Created by Camila Alba Agresta Kohen  
Created on 28/9/25 at 21:16
Universidad Carlos III de Madrid
Student

-------
Lab 3
Exercise: 6 - Multiple declarations (I)
Declare and initialize three variables of different types in a single line. Is this possible?
"""

my_str , my_int , my_bool = "hello world", 10 , True

print("str:", my_str ," int:", my_int ," bool:", my_bool)
