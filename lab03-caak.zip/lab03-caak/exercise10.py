"""
Bachelor in Data Science and Engineering 
Subject: Programming
Created by Camila Alba Agresta Kohen  
Created on 28/9/25 at 22:13
Universidad Carlos III de Madrid
Student

-------
Lab 3
Exercise: 10 - String concatenation
Declare three string variables, assigning any value to the first two and making the third variable equal to
the first one + second one. Print the third variable. What happens? What if you set the third variable = first –
second?
"""

str1 = "Data"
str2 = "science"

print(str1 + str2)
print(str1 - str2)

# The program gives an error
# You can add strings but not substract