"""
Bachelor in Data Science and Engineering 
Subject: Programming
Created by Camila Alba Agresta Kohen  
Created on 28/9/25 at 20:58
Universidad Carlos III de Madrid
Student

-------
Lab 3
Exercise: 1 - Using non-initialized variables

Declare a variable of any type without initializing it (do not give an initial value to it). What is the result?
Why?
"""

my_string =
my_integer =
my_float =
my_bool =

# The program give an error (SyntaxError: invalid syntax) because the variable is not defined
