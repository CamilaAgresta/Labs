"""
Bachelor in Data Science and Engineering 
Subject: Programming
Created by Camila Alba Agresta Kohen  
Created on 28/9/25 at 22:33
Universidad Carlos III de Madrid
Student

-------
Lab 3
Exercise: 14 -  Out of range operations
Create a float variable with a value out of range by multiplying two large numbers. What is the result? Now,
generate the out-of-range value using the power operator (**). What is the result?
"""

float1 = 2.718281828459045235360287471352662497757247093699959574966967627724076630
float2 = 3.141592653589793238462643383279502884197169399375105820974944592307816406
print(float1 * float2)
print(float1 ** float2)