"""
Bachelor in Data Science and Engineering 
Subject: Programming
Created by Camila Alba Agresta Kohen  
Created on 28/9/25 at 22:26
Universidad Carlos III de Madrid
Student

-------
Lab 3
Exercise: 12 - Slicing strings
Using the previously declared variable and String slicing operators, create three variables: the first one will
contain Twinkle, twinkle, little star, the second one Up above the world so high
and the third one how I wonder what you are. Print these variables.
"""
str1 = "Twinkle, twinkle, little star,"
str2 = "Up above the world so high"
str3 = "how I wonder what you are"

print(str1)
print(str2)
print(str3)
