"""
Bachelor in Data Science and Engineering 
Subject: Programming
Created by Camila Alba Agresta Kohen  
Created on 28/9/25 at 21:02
Universidad Carlos III de Madrid
Student

-------
Lab 3
Exercise: 3 - Changing the value of a variable
Declare and initialize a variable. Then, in a new statement, assign a new value to the variable. Is it possible to
change the value of a variable? Does the type of the variable make any difference? Display both the old and
new values of the variable on the screen.
"""

var = 9
print("original value:", var)

var = 2
print("new value:", var)

# It is correct to change the value of a variable
# The type does not matter
